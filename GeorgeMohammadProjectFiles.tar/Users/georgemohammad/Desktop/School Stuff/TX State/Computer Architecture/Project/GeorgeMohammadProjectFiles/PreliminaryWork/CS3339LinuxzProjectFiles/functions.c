char Int2Char(int val){
	char val1 = (char)val;
	char *val2 = &val1;
	return val2;
}

int Test(){
	return 1;
}
